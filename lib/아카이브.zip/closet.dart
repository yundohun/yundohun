import 'dart:typed_data';
import 'package:multi_image_picker/multi_image_picker.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:flutter/material.dart';
import 'package:lookup/main.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:ui';

class closet extends StatefulWidget {
  const closet({Key? key}) : super(key: key);

  @override
  State<closet> createState() => _closetState();
}

class _closetState extends State<closet> {
  List<Asset> images = <Asset>[];
  String _error = 'No Error Dectedted';

  void initState(){
    super.initState();
  }

  @override
  Future<void> loadAsset() async {
    List<Asset> resultList = <Asset>[];
    String error = 'No Error Detected';

    try{
      resultList = await MultiImagePicker.pickImages(
        maxImages: 300,
        enableCamera: true,
        selectedAssets: images,
        cupertinoOptions: CupertinoOptions(
          takePhotoIcon: "chat",

        ),
        materialOptions: MaterialOptions(
            actionBarColor: "#abcdef",
            actionBarTitle: "Example App",
            allViewTitle: "All Photos",
            useDetailsView: false,
            selectCircleStrokeColor: "#000000"
        ),
      );
    } on Exception catch (e){
      error = e.toString();
    }

    if (!mounted) return;

    setState(() {
      images = resultList;
      _error = error;
    });
    Navigator.push(context, MaterialPageRoute(builder: (c) => UploadStep1(images: images)));
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('옷장', style: TextStyle(color: Color(0xff191919),fontWeight: FontWeight.bold),),
        actions: [
          IconButton(onPressed: loadAsset, icon: Icon(Icons.add_box_outlined)),
        ],
      ),
      body: Container(),

      bottomNavigationBar: BtmNavBar(),

    );
  }
}

class UploadStep1 extends StatefulWidget {
  const UploadStep1({Key? key, this.images}) : super(key: key);
  final images;


  @override
  State<UploadStep1> createState() => _UploadStep1State();
}

class _UploadStep1State extends State<UploadStep1> {
  var _topCategory = ['아우터','상의','하의','신발','ACC'];
  var _selectedValue = '아우터';
  
  Widget imageLoader(context){
    var width = MediaQuery.of(context).size.width;
    return Center(
      child: Container(
        width: width,
        height: width,
        child: AssetThumb(asset: widget.images[0], width: 600, height: 600,)
      ),
    );
  }

  Widget buildGridView(){
    return GridView.count(
      crossAxisCount: 1,
      children: List.generate(widget.images.length, (index){
        Asset asset = widget.images[index];
        return AssetThumb(asset: asset, width: 300, height: 300);
      }),
    );
  }


  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('옷장 등록하기', style: TextStyle(
            fontWeight: FontWeight.bold, color: Color(0xff191919)),),
      ),
      body: Column(
        children: [Expanded(child: SingleChildScrollView(
          child: Column(
            children: [
              imageLoader(context),
              SizedBox(height: 20,),
              Container(
                  padding: EdgeInsets.only(left: 16),
                  alignment: Alignment.topLeft,
                  child: Text('옷 정보 입력',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text('카테고리',style: TextStyle(fontSize: 16),),
                  ),
                  DropdownButton(
                    value: _selectedValue,
                    items: _topCategory.map((value){
                      return DropdownMenuItem(
                          value: value,
                          child: Text(value));
                    }).toList(),
                    onChanged: (value){
                      setState(() {
                        _selectedValue = value.toString();
                      });
                    }),
                ],
              )

            ],
          ),
        )),

          Container(
            padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom),
            width: width,
            height: 84,
            child: ElevatedButton(child: Text('다음',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),onPressed: (){
            },
              style: ElevatedButton.styleFrom(
                primary: Color(0xff5C6EDA)
              ),),
          ),


        ],
      ),
    );
  }
}


class Upload extends StatefulWidget {
  const Upload({Key? key}) : super(key: key);

  @override
  State<Upload> createState() => _UploadState();

}

class _UploadState extends State<Upload> {
  var albums = <AssetPathEntity>[];
  var headerTitle = '';
  var imageList = <AssetEntity>[];
  AssetEntity? selectedImage;

  @override
  void initState() {
    super.initState();
    _loadPhotos();
  }

  void _loadPhotos() async {
    var result = await PhotoManager.requestPermissionExtend();
    if (result.isAuth) {
      albums = await PhotoManager.getAssetPathList(
          type: RequestType.image,
          filterOption: FilterOptionGroup(
              imageOption:
              FilterOption(
                sizeConstraint: SizeConstraint(minHeight: 100, minWidth: 100),
              ),
              orders: [
                OrderOption(type: OrderOptionType.createDate, asc: false),
              ]
          ));
      _loadData();
    } else {
      //message 권한 요청
    }
  }

  void _loadData() async {
    headerTitle = albums.first.name;
    await _pagingPhotos();
    update();
  }

  Future<void> _pagingPhotos() async {
    var photos = await albums.first.getAssetListPaged(0, 30);
    imageList.addAll(photos);

  }

  void update() => setState(() {});

  Widget _selectCategory() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('카테고리', style: TextStyle(fontSize: 18),),
            Icon(Icons.arrow_drop_down),
          ],
        ),
      ),
    );
  }

  Widget _imagePreview(context) {
    var width = MediaQuery.of(context).size.width;
    return Container(
        width: width,
        height: width,
        color: Colors.grey,
        child: selectedImage == null ? Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.image_outlined, color: Colors.white, size: 60,),
            SizedBox(height: 5,),
            Text('이미지를 등록하세요', style: TextStyle(color: Colors.white),)
          ],
        ) : _photoWidget(selectedImage!,width.toInt(),builder: (data){
          return Image.memory(
            data,
            fit: BoxFit.cover,
          );
        }),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: (){
              showModalBottomSheet(
                  context: context,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20)
                    )
                  ),
                  builder: (_)=>Container(
                    height: 200,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: List.generate(
                        albums.length,
                            (index) => Container(
                              padding: EdgeInsets.symmetric(
                                vertical: 15, horizontal: 20
                              ),
                              child: Text(albums[index].name),
                            )
                    ),
                  ),
                  ));
            },
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Row(
                children: [
                  Text(headerTitle,
                    style: TextStyle(color: Color(0xff191919), fontSize: 18),),
                  Icon(Icons.arrow_drop_down),
                ],
              ),
            ),
          ),
          Row(
            children: [
              Container(
                  padding: const EdgeInsets.symmetric(
                      vertical: 5, horizontal: 10),
                  decoration: BoxDecoration(color: Color(0xff808080),
                      borderRadius: BorderRadius.circular(30)),
                  child: Row(
                    children: [
                      Icon(Icons.filter, color: Colors.white,),
                      SizedBox(width: 7,),
                      Text('여러 항목 선택', style: TextStyle(
                          color: Color(0xffffffff), fontSize: 14),),
                    ],
                  )),
              SizedBox(
                width: 5,
              ),
              Container(
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xff808080),
                ),
                child: Icon(Icons.camera_alt_outlined, color: Colors.white,),
              )
            ],
          ),

        ],
      ),
    );
  }

  Widget _imageSelectList() {
    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 1,
        mainAxisSpacing: 1,
        crossAxisSpacing: 1,
      ),
      itemCount: imageList.length,
      itemBuilder: (context, index) {
        return _photoWidget(imageList[index],200, builder: (data){
           return GestureDetector(
             onTap: (){
               selectedImage = imageList[index];
               update();
             },
             child: Opacity(
              opacity: imageList[index] == selectedImage ? 0.3 : 1,
              child: Image.memory(
                data,
                fit: BoxFit.cover,),
          ),
           );
        });
      },
    );
  }

  Widget _photoWidget(AssetEntity asset, int size, {required Widget Function(Uint8List) builder}) {
    return FutureBuilder(
        future: asset.thumbDataWithSize(size, size),
        builder: (_, AsyncSnapshot<Uint8List?> snapshot) {
          if (snapshot.hasData) {
            return builder(snapshot.data!);
          } else {
            return Container();
          }
        }
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          onPressed: () {},
          icon: Icon(Icons.close),
        ),
        title: Text('옷장 등록하기', style: TextStyle(
            fontWeight: FontWeight.bold, color: Color(0xff191919)),),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.navigate_next))
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _selectCategory(),
            _imagePreview(context),
            _header(),
            _imageSelectList(),
          ],
        ),
      ),
    );
  }
}


